﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

class Program
{
    static void Main()
    {
        using var context = new ForgeContext();
        context.Database.EnsureCreated();
        SampleDataSeeder.Seed(context);

        var forgeOperations = context.ForgeOperations
            .Include(f => f.Item)
            .ThenInclude(i => i.Materials)
            .ToList();

        foreach (var op in forgeOperations)
        {
            Console.WriteLine($"Item: {op.Item.Name}");
            Console.WriteLine($"Quantity: {op.Quantity}");
            Console.WriteLine("Materials:");
            foreach (var mat in op.Item.Materials)
            {
                Console.WriteLine($" - {mat.Name}: {mat.Quantity} x {mat.BazaarPrice:C} = {mat.TotalCost:C}");
            }
            Console.WriteLine($"Output Price: {op.Item.ForgeOutputPrice:C}");
            Console.WriteLine($"Total Input Cost: {op.Item.TotalInputCost:C}");
            Console.WriteLine($"Profit per Forge: {op.Item.ProfitPerForge:C}");
            Console.WriteLine($"Total Profit: {op.TotalProfit:C}");
            Console.WriteLine(new string('-', 40));
        }
    }
}
