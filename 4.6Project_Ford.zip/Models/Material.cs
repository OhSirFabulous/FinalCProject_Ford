public class Material
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Quantity { get; set; }
    public decimal BazaarPrice { get; set; }

    public decimal TotalCost => Quantity * BazaarPrice;

    // Relationship
    public int ItemId { get; set; }
    public Item Item { get; set; }
}
