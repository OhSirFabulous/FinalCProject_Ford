using System.Collections.Generic;
using System.Linq;

public class Item
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal ForgeOutputPrice { get; set; }

    public List<Material> Materials { get; set; } = new();
    public decimal TotalInputCost => Materials.Sum(m => m.TotalCost);
    public decimal ProfitPerForge => ForgeOutputPrice - TotalInputCost;
}
