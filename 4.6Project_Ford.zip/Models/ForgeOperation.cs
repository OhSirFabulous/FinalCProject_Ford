public class ForgeOperation
{
    public int Id { get; set; }
    public int Quantity { get; set; }

    // Foreign Key to Item
    public int ItemId { get; set; }
    public Item Item { get; set; }

    public decimal TotalCost => Item.TotalInputCost * Quantity;
    public decimal TotalProfit => Item.ProfitPerForge * Quantity;
}
