using Microsoft.EntityFrameworkCore;

public class ForgeContext : DbContext
{
    public DbSet<Item> Items { get; set; }
    public DbSet<Material> Materials { get; set; }
    public DbSet<ForgeOperation> ForgeOperations { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=ForgeCalculator.db");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Item>()
            .HasMany(i => i.Materials)
            .WithOne(m => m.Item)
            .HasForeignKey(m => m.ItemId);

        modelBuilder.Entity<ForgeOperation>()
            .HasOne(f => f.Item)
            .WithMany()
            .HasForeignKey(f => f.ItemId);
    }
}
