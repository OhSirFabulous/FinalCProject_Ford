public static class SampleDataSeeder
{
    public static void Seed(ForgeContext context)
    {
        if (!context.Items.Any())
        {
            var mithril = new Item
            {
                Name = "Refined Mithril",
                ForgeOutputPrice = 585324m,
                Materials = new List<Material>
                {
                    new Material { Name = "Enchanted Mithril", Quantity = 160, BazaarPrice = 1266m }
                }
            };

            var titanium = new Item
            {
                Name = "Refined Titanium",
                ForgeOutputPrice = 594539m,
                Materials = new List<Material>
                {
                    new Material { Name = "Enchanted Titanium", Quantity = 16, BazaarPrice = 9842m }
                }
            };

            context.Items.AddRange(mithril, titanium);
            context.SaveChanges();

            var forge1 = new ForgeOperation { Quantity = 7, ItemId = mithril.Id };
            var forge2 = new ForgeOperation { Quantity = 7, ItemId = titanium.Id };

            context.ForgeOperations.AddRange(forge1, forge2);
            context.SaveChanges();
        }
    }
}
