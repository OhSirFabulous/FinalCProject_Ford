﻿using ForgeCalculator.Data;
using ForgeCalculator.Models;
using System;
using System.Globalization;

namespace ForgeCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            var forgeOperations = SampleData.GetForgeOperations();

            foreach (var operation in forgeOperations)
            {
                Console.WriteLine($"Item: {operation.Item.Name}");
                Console.WriteLine($"Quantity: {operation.Quantity}");
                Console.WriteLine("Materials:");
                foreach (var material in operation.Item.Materials)
                {
                    Console.WriteLine($"  - {material.Name}: {material.Quantity} x {material.BazaarPrice.ToString("C", CultureInfo.CurrentCulture)} = {material.TotalCost.ToString("C", CultureInfo.CurrentCulture)}");
                }
                Console.WriteLine($"Forge Output Price: {operation.Item.ForgeOutputPrice.ToString("C", CultureInfo.CurrentCulture)}");
                Console.WriteLine($"Total Input Cost: {operation.Item.TotalInputCost.ToString("C", CultureInfo.CurrentCulture)}");
                Console.WriteLine($"Profit per Forge: {operation.Item.ProfitPerForge.ToString("C", CultureInfo.CurrentCulture)}");
                Console.WriteLine($"Total Cost for {operation.Quantity} Forges: {operation.TotalCost.ToString("C", CultureInfo.CurrentCulture)}");
                Console.WriteLine($"Total Profit for {operation.Quantity} Forges: {operation.TotalProfit.ToString("C", CultureInfo.CurrentCulture)}");
                Console.WriteLine(new string('-', 50));
            }
        }
    }
}
