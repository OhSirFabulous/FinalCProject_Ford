using ForgeCalculator.Models;
using System.Collections.Generic;

namespace ForgeCalculator.Data
{
    public static class SampleData
    {
        public static List<ForgeOperation> GetForgeOperations()
        {
            return new List<ForgeOperation>
            {
                new ForgeOperation
                {
                    Item = new Item
                    {
                        Name = "Refined Mithril",
                        Materials = new List<Material>
                        {
                            new Material { Name = "Enchanted Mithril", Quantity = 160, BazaarPrice = 1266m }
                        },
                        ForgeOutputPrice = 585324m
                    },
                    Quantity = 7
                },
                new ForgeOperation
                {
                    Item = new Item
                    {
                        Name = "Refined Titanium",
                        Materials = new List<Material>
                        {
                            new Material { Name = "Enchanted Titanium", Quantity = 16, BazaarPrice = 9842m }
                        },
                        ForgeOutputPrice = 594539m
                    },
                    Quantity = 7
                },
                // Add more ForgeOperations as needed
            };
        }
    }
}
