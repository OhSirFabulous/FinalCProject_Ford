using System.Collections.Generic;
using System.Linq;

namespace ForgeCalculator.Models
{
    public class Item
    {
        public string Name { get; set; }
        public List<Material> Materials { get; set; } = new List<Material>();
        public decimal ForgeOutputPrice { get; set; }

        public decimal TotalInputCost => Materials.Sum(m => m.TotalCost);
        public decimal ProfitPerForge => ForgeOutputPrice - TotalInputCost;
    }
}
