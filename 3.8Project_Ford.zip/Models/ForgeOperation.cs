namespace ForgeCalculator.Models
{
    public class ForgeOperation
    {
        public Item Item { get; set; }
        public int Quantity { get; set; }

        public decimal TotalCost => Item.TotalInputCost * Quantity;
        public decimal TotalProfit => Item.ProfitPerForge * Quantity;
    }
}
