namespace ForgeCalculator.Models
{
    public class Material
    {
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal BazaarPrice { get; set; }

        public decimal TotalCost => Quantity * BazaarPrice;
    }
}
